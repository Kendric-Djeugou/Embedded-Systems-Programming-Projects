#include "hal.h"
#include "project.h"
#include "concurrent.h"

void setup() {
    HAL_init();
    Concurrent_init();
}

void loop() {    
    Concurrent_run();
}