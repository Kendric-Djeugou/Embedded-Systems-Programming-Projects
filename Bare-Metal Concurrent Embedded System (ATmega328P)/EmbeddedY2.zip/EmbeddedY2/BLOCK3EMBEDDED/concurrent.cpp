#include "concurrent.h"
#include "project.h"
#include "hal.h"

// Maximum number of tasks that can be scheduled
#define MAX_TASKS 10

// Array storing all registered tasks
static Task tasks[MAX_TASKS];

// Current number of tasks added to the scheduler
static byte taskCount = 0;

// =====================================================
// ================== ADD TASK ===========================
// =====================================================
// Adds a new task to the scheduler with a given execution period
static void addTask(TaskFunction f, unsigned long period)
{
    // Ensure we do not exceed the maximum allowed tasks
    if (taskCount < MAX_TASKS)
    {
        // Store task function, its period, and initialise lastRun to 0
        tasks[taskCount++] = {f, period, 0};
    }
}

// =====================================================
// ================== MODE CONTROL =======================
// =====================================================
// Controls which application tasks run depending on the current mode
static void modeControlledTask()
{
    switch(mode)
    {
        case 1:
            // Mode 1  Traffic lights only
            trafficLightsTask();
            break;

        case 2:
            // Mode 2  Voltage indicator only
            voltageTask();
            break;

        case 3:
            // Mode 3  Counter only (LEDs must be OFF)
            ledState = LEDS_OFF;
            counterTask();
            break;

        case 4:
            // Mode 4  Traffic lights + Counter
            trafficLightsTask();
            counterTask();
            break;

        case 5:
            // Mode 5  Voltage indicator + Counter
            voltageTask();
            counterTask();
            break;
    }
}

// =====================================================
// ================== OUTPUT TASK ========================
// =====================================================
// This is the ONLY task allowed to write to PORTD
static void outputTask()
{
    PORTD = ledState;
}

// =====================================================
// ================== INITIALISATION =====================
// =====================================================
// Registers all tasks with their execution periods
void Concurrent_init()
{
    addTask(HB_task, 10);              // Heartbeat (checked frequently, internal timing = 270ms)
    addTask(debounceSW1Task, 20);      // Debounce SW1 (20ms)
    addTask(debounceSW2Task, 20);      // Debounce SW2 (20ms)
    addTask(modeTask, 50);             // Mode switching (less frequent)

    addTask(modeControlledTask, 10);   // Main application logic (runs continuously)
    addTask(displayTask, 10);          // Display refresh (fast for stability)
    addTask(outputTask, 10);           // LED output update 
}

// =====================================================
// ================== SCHEDULER RUN ======================
// =====================================================
// Executes tasks when their period has elapsed
void Concurrent_run()
{
    // Get current system time (non-blocking timing reference)
    unsigned long now = millis();

    // Iterate through all registered tasks
    for (byte i = 0; i < taskCount; i++)
    {
        // Check if the task's period has elapsed
        if (now - tasks[i].lastRun >= tasks[i].period)
        {
            // Update last execution time
            tasks[i].lastRun = now;

            // Execute the task
            tasks[i].task();
        }
    }
}