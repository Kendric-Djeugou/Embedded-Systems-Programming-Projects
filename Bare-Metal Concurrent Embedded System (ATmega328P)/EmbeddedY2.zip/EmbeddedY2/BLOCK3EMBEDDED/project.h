#ifndef PROJECT_H
#define PROJECT_H

#include <Arduino.h>

// STATES
typedef enum
{
  NOT_PRESSED,
  PARTIAL_PRESS,
  DEBOUNCED_PRESS
} switch_state_t;

// GLOBALS
extern byte counter;
extern byte mode;
extern switch_state_t B1_state;
extern switch_state_t B2_state;

// SHARED OUTPUT
extern volatile byte ledState;

// =====================================================
// ================== FUNCTION PROTOTYPES ================
// =====================================================
void HB_task();
void debounceSW1Task();
void debounceSW2Task();
void counterTask();
void trafficLightsTask();
void voltageTask();
void displayTask();
void modeTask();

#endif