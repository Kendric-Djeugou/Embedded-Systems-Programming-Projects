#include "hal.h"
// =====================================================
// ==================   HEX TABLE   ====================
// =====================================================
const byte hexTable[16] =
{
    0b00111111,0b00000110,0b01011011,0b01001111,
    0b01100110,0b01101101,0b01111101,0b00000111,
    0b01111111,0b01101111,0b01110111,0b01111100,
    0b00111001,0b01011110,0b01111001,0b01110001
};
// =====================================================
// ================== HARWARE INITIALISATIION ====================
// =====================================================
void HAL_init()
{
    DDRB |= HAL_CLOCK | HAL_DATA | HAL_LATCH;
    DDRD |= 0b11111100;

    DDRC &= ~(SW1 | SW2);
    PORTC |= (SW1 | SW2);
}
// =====================================================
// ================== SHIFT REGISTER ====================
// =====================================================
static void toggleCLK() {
    HAL_CLK_HI;
    HAL_CLK_LO;
}

static void toggleLatch() {
    HAL_LATCH_HI;
    HAL_LATCH_LO;
}

static void shiftBit(bool data)
{
    if (data) HAL_DATA_HI;
    else HAL_DATA_LO;

    toggleCLK();
}
void HAL_writeToShiftRegister(byte value)
{
    byte mask = 0b10000000;

    HAL_LATCH_LO;

    for (int i = 0; i < 8; i++)
    {
        shiftBit(value & mask);
        mask >>= 1;
    }

    toggleLatch();
}