#ifndef CONCURRENT_H
#define CONCURRENT_H

#include <Arduino.h>

// =====================================================
// ================== TASK FUNCTION TYPE =================
// =====================================================
// Defines a function pointer type for tasks
typedef void (*TaskFunction)();           // Each task is a function that takes no parameters and returns nothing

// =====================================================
// ================== TASK STRUCTURE =====================
// =====================================================

typedef struct
{
    TaskFunction task;        // Pointer to the task function to execute
    unsigned long period;     // Time interval (in ms) between executions
    unsigned long lastRun;    // Timestamp of the last execution (used for scheduling)
} Task;

// =====================================================
// ================== FUNCTION PROTOTYPES ================
// =====================================================

// Initialises the concurrent scheduler
void Concurrent_init();
void Concurrent_run();

#endif