#include "project.h"
#include "hal.h"

// ================== GLOBALS ==================
byte counter = 0;
byte mode = 1;
switch_state_t B1_state = NOT_PRESSED;
switch_state_t B2_state = NOT_PRESSED;

volatile byte ledState = 0;

// ================== HEARTBEAT ==================
bool hb_state = false;
unsigned long hb_time = 0;

void HB_task()
{
    if (millis() - hb_time >= 270)
    {
        hb_time = millis();
        hb_state = !hb_state;
    }
}

// ================== PRIORITY ==================
int getPriority()
{
    byte val = counter & 0x0F;

    if (val <= 9) return 0;       // Equal
    else if (val <= 12) return 1; // Set1 priority
    else return 2;                // Set2 priority
}

// ================== DEBOUNCE ==================
void debounceSW1Task()
{
    static unsigned long t;
    static switch_state_t state = NOT_PRESSED;

    switch(state)
    {
        case NOT_PRESSED:
            if (SW1_PRESSED) { 
              t = millis(); state = PARTIAL_PRESS; 
              }
            break;

        case PARTIAL_PRESS:
            if (!SW1_PRESSED) state = NOT_PRESSED;
            else if (millis() - t >= 300)   //300ms Debounce time
            state = DEBOUNCED_PRESS;
            break;

        case DEBOUNCED_PRESS:
            if (!SW1_PRESSED)
            state = NOT_PRESSED;
            break;
    }
    B1_state = state;
}

void debounceSW2Task()
{
    static unsigned long t;
    static switch_state_t state = NOT_PRESSED;

    switch(state)
    {
        case NOT_PRESSED:
            if (SW2_PRESSED) { 
              t = millis(); state = PARTIAL_PRESS;
               }
            break;

        case PARTIAL_PRESS:
            if (!SW2_PRESSED) state = NOT_PRESSED;
            else if (millis() - t >= 300)
            state = DEBOUNCED_PRESS;
            break;

        case DEBOUNCED_PRESS:
            if (!SW2_PRESSED) state = NOT_PRESSED;
            break;
    }

    B2_state = state;
}

// ================== COUNTER ==================
void counterTask()
{
    static switch_state_t old = NOT_PRESSED;

    if (B1_state == DEBOUNCED_PRESS && old != DEBOUNCED_PRESS)
        counter++;

    old = B1_state;
}

// ================== TRAFFIC LIGHTS ==================
void trafficLightsTask()
{
    static unsigned long t = 0;
    static int state = 0;
    static unsigned long delayTime = 1000;

    if (millis() - t >= delayTime)
    {
        switch (state)
        {
            case 0: // State 0. LEDs Y1 & Y2 on for 1s
                ledState = HAL_S1_YELLOW | HAL_S2_YELLOW;
                delayTime = 1000;
                state = 1;
                break;
            case 1: // State 0 LED R1 & LED R2 on for 2s
                ledState = HAL_S1_RED | HAL_S2_RED;
                delayTime = 2000;
                state = 2;
                break;

            case 2: // State 2. LEDs R1,R2 & Y1 on for 1s
                ledState = HAL_S1_RED | HAL_S2_RED | HAL_S1_YELLOW;
                delayTime = 1000;
                state = 3;
                break;

            case 3: // State 3. LEDs R2 & G1 time depends on priority
                ledState = HAL_S2_RED | HAL_S1_GREEN;

                if (getPriority() == 0) delayTime = 6000;
                else if (getPriority() == 1) delayTime = 8000;
                else delayTime = 4000;

                state = 4;
                break;

            case 4: // State 4. LEDs R2 & Y1 on for 1s
                ledState = HAL_S2_RED | HAL_S1_YELLOW;
                delayTime = 2000;
                state = 5;
                break;

            case 5:  // State 5. LEDs R2 & R1 on for 1s
                ledState = HAL_S2_RED | HAL_S1_RED;
                delayTime = 1000;
                state = 6;
                break;

            case 6:   // State 6. LEDs R1,R2 & Y2 on for 1s
                ledState = HAL_S1_RED | HAL_S2_RED | HAL_S2_YELLOW;
                delayTime = 1000;
                state = 7;
                break;

            case 7:   // State 7. LEDs R1 & G2 depends on priority
                ledState = HAL_S1_RED | HAL_S2_GREEN;

                if (getPriority() == 0) delayTime = 6000;
                else if (getPriority() == 1) delayTime = 4000;
                else delayTime = 8000;

                state = 8;
                break;

            case 8: // State 8. LEDs R1 & Y2 on for 2s
                ledState = HAL_S1_RED | HAL_S2_YELLOW;
                delayTime = 2000;
                state = 1;
                break;
        }

        t = millis();
    }
}

// ================== VOLTAGE ==================
void voltageTask()
{
    static unsigned long t = 0;

    if (millis() - t >= 40)
    {
        t = millis();

        int adc = analogRead(A0);
        float v = adc * 5.0 / 1023.0;

        if (v >= 4.0) ledState = HAL_S2_RED;
        else if (v >= 3.0) ledState = HAL_S1_RED;
        else if (v >= 2.0) ledState = HAL_S1_YELLOW | HAL_S2_YELLOW;
        else if (v >= 1.0) ledState = HAL_S2_GREEN;
        else ledState = HAL_S1_GREEN;
    }
}

// ================== DISPLAY ==================
void displayTask()
{
    byte value;

    if(mode == 1) value = 0b01111000; // 't'
    else if(mode == 2) value = 0b00111000; // 'L'
    else value = hexTable[counter & 0x0F];

    if (hb_state) value |= 0x80;
    else value &= 0x7F;

    HAL_writeToShiftRegister(value);
}

// ================== MODE ==================
void modeTask()
{
    static switch_state_t old = NOT_PRESSED;

    if (B2_state == DEBOUNCED_PRESS && old != DEBOUNCED_PRESS)
    {
        mode++;
        if (mode > 5) mode = 1;
    }

    old = B2_state;
}