#ifndef HAL_H
#define HAL_H

#include <Arduino.h>

// =====================================================
// ================== PIN DEFINITIONS ==================
// =====================================================
// HEX TABLE
extern const byte hexTable[16];

// OFF 7-SEGMENT
#define DISPLAY_OFF 0x00

// SHIFT REGISTER
#define HAL_DATA    0b00001000
#define HAL_CLOCK   0b00010000
#define HAL_LATCH   0b00100000

// SWITCHES
#define SW1 0b00000100
#define SW2 0b00001000

//                     State Definitions 
// SWITCHES
#define SW1_PRESSED  !(PINC & SW1)
#define SW2_PRESSED  !(PINC & SW2)

// LEDS
#define LEDS_OFF  B00000000
#define HAL_S2_GREEN  B10000000
#define HAL_S2_YELLOW B01000000
#define HAL_S2_RED    B00100000
#define HAL_S1_GREEN  B00010000
#define HAL_S1_YELLOW B00001000
#define HAL_S1_RED    B00000100

// LOW LEVEL
#define HAL_CLK_HI    PORTB |=  HAL_CLOCK
#define HAL_CLK_LO    PORTB &= ~HAL_CLOCK
#define HAL_LATCH_HI  PORTB |=  HAL_LATCH
#define HAL_LATCH_LO  PORTB &= ~HAL_LATCH
#define HAL_DATA_HI   PORTB |=  HAL_DATA
#define HAL_DATA_LO   PORTB &= ~HAL_DATA

//            Function Prototypes
void HAL_init();
void HAL_writeToShiftRegister(byte value);

#endif